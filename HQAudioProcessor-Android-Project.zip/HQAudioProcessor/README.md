# HQ Audio Processor — Android Capture prototype

Prototype Android Studio project for Android 10+ (API 29+) using system playback capture, Kotlin foreground service, AudioTrack output, and a native C++ stereo DSP engine.

## Important behavior / limitation

Android `AudioPlaybackCapture` is opt-in per source app. It generally captures only eligible playback usages from apps that allow capture. Protected content and apps that disable capture are unavailable. This app cannot replace/mute the source app's original output. Therefore, the unprocessed original audio may remain audible while this app plays the processed copy. This is a platform limitation, not a DSP bug. A true system-wide insert processor requires privileged/system-level audio routing or control of the source player.

Bluetooth output follows Android's current media output route. Pair/select the Bluetooth device in Android Quick Settings before starting. The app does not force A2DP routing because Android manages route selection and newer Bluetooth devices may use different profiles/codecs.

## Build

1. Install Android Studio (JDK 17) and Android SDK Platform 35, NDK, and CMake.
2. Open this folder in Android Studio.
3. Allow Gradle sync.
4. Connect an Android 10+ phone, enable USB debugging, and run `app`.
5. Pair/select Bluetooth audio output in Android settings.
6. Tap **MULAI SYSTEM CAPTURE**, approve Android's screen/audio capture consent, then play audio from an app that permits playback capture.
7. Tap **STOP DSP** to stop.

Build APK: Android Studio > Build > Build Bundle(s) / APK(s) > Build APK(s). Debug APK normally appears at `app/build/outputs/apk/debug/app-debug.apk`.

## Current implementation

- Stereo 48 kHz float PCM capture and output.
- C++ 31-band peaking EQ biquad bank (flat by default; JNI setter ready).
- Basic stereo-linked compressor with output ceiling.
- Foreground media-projection service.
- Minimal start/stop UI.

## Not yet implemented

- Interactive EQ sliders and saving presets.
- Adjustable crossover / Linkwitz-Riley filters and routing UI.
- Full-featured compressor controls, RMS/peak meters, delay and phase UI.
- Robust resampling / device-rate negotiation, underrun diagnostics, audio focus policy, and device-specific Bluetooth latency tuning.
- Production-grade real-time engine. Current JNI float-array bridge is a prototype; use direct buffers or Oboe/AAudio and add a lock-free parameter queue for production.

## Audio processing note

The current 31 EQ bands are configured flat. The native API `setEqBand(index, frequencyHz, gainDb, q)` is ready to be connected to UI controls. Crossover is deliberately not exposed yet: 2-in/2-out crossover needs a defined routing policy (e.g. stereo 2-way means each input split into low/high, which would require 4 output channels, not 2). For 2-in/2-out, a stereo full-range processor is the consistent topology.
