#include <jni.h>
#include <array>
#include <cmath>
#include <algorithm>
#include <cstdint>

namespace {
constexpr int kBands = 31;
constexpr float kPi = 3.14159265358979323846f;
struct Biquad {
    float b0=1, b1=0, b2=0, a1=0, a2=0;
    float z1L=0, z2L=0, z1R=0, z2R=0;
    void setPeaking(float fs, float f, float gainDb, float q) {
        f = std::clamp(f, 10.0f, fs * 0.45f);
        q = std::max(q, 0.1f);
        const float A = std::pow(10.0f, gainDb / 40.0f);
        const float w = 2.0f * kPi * f / fs;
        const float c = std::cos(w), s = std::sin(w), alpha = s / (2.0f*q);
        const float a0 = 1.0f + alpha/A;
        b0 = (1.0f + alpha*A)/a0;
        b1 = (-2.0f*c)/a0;
        b2 = (1.0f - alpha*A)/a0;
        a1 = (-2.0f*c)/a0;
        a2 = (1.0f - alpha/A)/a0;
    }
    inline float tick(float x, float &z1, float &z2) {
        const float y = b0*x + z1;
        z1 = b1*x - a1*y + z2;
        z2 = b2*x - a2*y;
        return y;
    }
};
struct Engine {
    float fs;
    std::array<Biquad,kBands> eq{};
    float thresholdDb=-12.0f, ratio=2.0f, attackMs=10.0f, releaseMs=120.0f;
    float env=0.0f, gain=1.0f;
    explicit Engine(float rate): fs(rate) {
        const float freqs[kBands]={20,25,31.5,40,50,63,80,100,125,160,200,250,315,400,500,630,800,1000,1250,1600,2000,2500,3150,4000,5000,6300,8000,10000,12500,16000,20000};
        for(int i=0;i<kBands;i++) eq[i].setPeaking(fs,freqs[i],0.0f,1.0f);
    }
    void setBand(int i,float f,float db,float q){ if(i>=0&&i<kBands) eq[i].setPeaking(fs,f,db,q); }
    void setComp(float th,float r,float a,float rel){ thresholdDb=th; ratio=std::max(1.0f,r); attackMs=std::max(0.1f,a); releaseMs=std::max(1.0f,rel); }
    void process(float* x,int n){
        // n is number of interleaved samples; stereo frame count is n/2.
        const float attack=std::exp(-1.0f/(fs*(attackMs/1000.0f)));
        const float release=std::exp(-1.0f/(fs*(releaseMs/1000.0f)));
        const float threshold=std::pow(10.0f,thresholdDb/20.0f);
        for(int i=0;i+1<n;i+=2){
            float l=x[i], r=x[i+1];
            for(auto &b:eq){ l=b.tick(l,b.z1L,b.z2L); r=b.tick(r,b.z1R,b.z2R); }
            const float peak=std::max(std::abs(l),std::abs(r));
            const float coeff=(peak>env)?attack:release;
            env=coeff*env+(1.0f-coeff)*peak;
            float target=1.0f;
            if(env>threshold && env>1e-9f){
                const float overDb=20.0f*std::log10(env/threshold);
                const float reductionDb=overDb-(overDb/ratio);
                target=std::pow(10.0f,-reductionDb/20.0f);
            }
            // Fast gain smoothing prevents zipper noise; hard safety ceiling at -1 dBFS.
            gain=0.85f*gain+0.15f*target;
            l*=gain; r*=gain;
            const float ceiling=0.8912509f;
            l=std::clamp(l,-ceiling,ceiling); r=std::clamp(r,-ceiling,ceiling);
            x[i]=l; x[i+1]=r;
        }
    }
};
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_hqaudio_processor_NativeDsp_nativeCreate(JNIEnv*, jobject, jint sampleRate) {
    return reinterpret_cast<jlong>(new Engine(static_cast<float>(sampleRate)));
}
extern "C" JNIEXPORT void JNICALL
Java_com_hqaudio_processor_NativeDsp_nativeSetEqBand(JNIEnv*, jobject, jlong h, jint index, jfloat f, jfloat db, jfloat q) {
    auto* e=reinterpret_cast<Engine*>(h); if(e) e->setBand(index,f,db,q);
}
extern "C" JNIEXPORT void JNICALL
Java_com_hqaudio_processor_NativeDsp_nativeSetCompressor(JNIEnv*, jobject, jlong h, jfloat th, jfloat ratio, jfloat attack, jfloat release) {
    auto* e=reinterpret_cast<Engine*>(h); if(e) e->setComp(th,ratio,attack,release);
}
extern "C" JNIEXPORT void JNICALL
Java_com_hqaudio_processor_NativeDsp_nativeProcess(JNIEnv* env, jobject, jlong h, jfloatArray array, jint validSamples) {
    auto* e=reinterpret_cast<Engine*>(h); if(!e||!array) return;
    const jsize len=env->GetArrayLength(array); const jint n=std::clamp(validSamples,0,static_cast<jint>(len));
    jfloat* p=env->GetFloatArrayElements(array,nullptr); if(!p) return;
    e->process(p,n); env->ReleaseFloatArrayElements(array,p,0);
}
extern "C" JNIEXPORT void JNICALL
Java_com_hqaudio_processor_NativeDsp_nativeDestroy(JNIEnv*, jobject, jlong h) {
    delete reinterpret_cast<Engine*>(h);
}
